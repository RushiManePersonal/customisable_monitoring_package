# Shared utility functions
